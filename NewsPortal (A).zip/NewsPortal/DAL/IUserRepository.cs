﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
   public interface IUserRepository<T, ID>
    {
        void Add(T e);
        void Edit(T e);
        List<T> Get();
        T Get(ID id);
    }
}
