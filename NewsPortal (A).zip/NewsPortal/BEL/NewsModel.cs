﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BEL
{
    public class NewsModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Date { get; set; }
        public int NewsCategoryId { get; set; }
        public string React { get; set; }
        public string Comments { get; set; }

        public virtual CategoriesModel CategoriesModel { get; set; }
    }
}
