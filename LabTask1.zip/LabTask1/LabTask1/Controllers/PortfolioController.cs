﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LabTask1.Controllers
{
    public class PortfolioController : Controller
    {
        // GET: Portfolio
        public ActionResult Education()
        {
            return View();
        }
        public ActionResult PerInformation()
        {
            return View();
        }
        public ActionResult Reference()
        {
            return View();
        }
        public ActionResult Bio()
        {
            return View();
        }
        public ActionResult Projects()
        {
            return View();
        }

    }
}